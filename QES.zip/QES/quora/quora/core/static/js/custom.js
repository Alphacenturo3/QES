(function ($) {
	$('ul.dl-menu li a').smoothScroll();


	//animation
	new WOW().init();

})(jQuery);
