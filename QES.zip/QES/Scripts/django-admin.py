#!c:\users\lenovo\desktop\project_1\quora-clone-master\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
